This is a simply library that makes the Math library easy to use.
We also added more functions to this, such as basic socket functions.

The functions include:

ip() - Get ip addr

wait(num) - time.sleep() function simplified

libs() --> Easier version of pip freeze >> ~.txt

add(x, y)

sub(x, y) - subtract

mul(x, y) - multiply

div(x, y) - divide

power(x, y) - x^y

intdiv(x, y) - x // y

modl(x, y) - x % y

value(x, y) - < or >

acos(x) - acos

acosh(x) - acosh

asin(x) - asin

asinh(x) - asinh

atan(x) - atan

atan2(x) - atan2

ceil(x) - ceiling functions

comb(x) - comb

copsig(x) - copysign

cos(x) - cosin  

cosh(x) - cosh

deg(x) - degrees

dist(x, y) - distance

erf(x) - error func 

exp(x) - exp

expm(x) - expm1

abs(x) - abosult value

fact(x) - factorial

flr(x) - floor func

fmod(x) - fmod

frexp(x) - frexp

gsum(x) - gsum

gamma(x) - gamma

gcd(x, y) - gre. com. div.

hypot(x) - hypot

icl(c, x) - isclose

ifin(x) - isfinite

iinf(x) - isInfinite

inan(x) - isNaN

flsqrt(x) - floorSqrt

log(x) - logarithms

log1(x) - log1p

log2(x) - log2

radc(x) - convert to radians

sin(x)  - sin

sinh(x) - sinh

sqrt(x) - sqrt

tan(x) - tan

tanh(x) - tanh

trunc(x) - trunc

e() - euler number

pi() - 3.14.....

tau() - number print